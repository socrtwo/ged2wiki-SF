gedcom2wiki - macOS distribution

Double-click launch.command to open the app in your default browser.

This build is UNSIGNED. Gatekeeper will block launch.command the first
time: right-click (or Control-click) launch.command -> Open -> Open.
