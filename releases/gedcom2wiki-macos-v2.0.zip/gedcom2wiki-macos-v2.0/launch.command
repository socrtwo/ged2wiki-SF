#!/usr/bin/env bash
# gedcom2wiki launcher for macOS
cd "$(dirname "$0")"
open "index.html"
