gedcom2wiki - Windows distribution

Double-click launch.bat to open the app in your default browser.

This build is UNSIGNED. Windows SmartScreen may warn the first time you
run launch.bat; click "More info" -> "Run anyway" to proceed.
