@echo off
rem gedcom2wiki launcher for Windows
start "" "%~dp0index.html"
