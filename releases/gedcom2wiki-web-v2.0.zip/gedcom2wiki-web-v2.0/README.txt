gedcom2wiki - Web distribution

Open index.html in any modern browser, or host this folder on any
static web server (GitHub Pages, Netlify, Cloudflare Pages, S3, etc.).

All processing runs locally in the browser. No server-side code.
