#!/usr/bin/env bash
# gedcom2wiki launcher for Linux
cd "$(dirname "$0")"
if   command -v xdg-open >/dev/null 2>&1; then xdg-open "index.html"
elif command -v gio      >/dev/null 2>&1; then gio open  "index.html"
elif command -v sensible-browser >/dev/null 2>&1; then sensible-browser "index.html"
else
  echo "No launcher found. Open index.html in your browser manually." >&2
  exit 1
fi
