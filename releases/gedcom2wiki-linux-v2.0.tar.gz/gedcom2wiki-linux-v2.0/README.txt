gedcom2wiki - Linux distribution

Run ./launch.sh to open the app in your default browser.

Alternatively, copy gedcom2wiki.desktop to ~/.local/share/applications
and edit the Exec/Icon paths to the absolute extracted location.
